import './App.css';
import { GridExample } from './Table';
// import { TestExample } from './TestTable';


function App() {
  return (
    <GridExample/>
    // <TestExample/>
  );
}

export default App;
