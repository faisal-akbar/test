## Oracle and MySQL Query Builder For AG-GRID

```
npm install
```
### Oracle:
```
npm run oracle
<!-- or -->
npm run oracle2
```

### MySQL:
```
npm run mysql
<!-- or -->
npm run mysql2
```

Note: Make sure change the host, user, password, connectionString, schema/table name etc based on you db and field names, table name in app.get('/filters',(req,res)=>{}) routes.