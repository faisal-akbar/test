const express =require('express');
const cors =require('cors');

let DataService= require('./dataServiceOracle');
let dataService = new DataService;


const app = express();
app.use(cors())

app.use(express.urlencoded({extended: true})); 

app.use(express.json());

const port = 8000

app.post('/data', function (req, res) {
    dataService.getData(req.body, (rows, lastRow) => {
        console.log("req response body", req.body)
        console.log("req response row",rows)
        console.log("req response last row", lastRow)
        res.json({rows: rows, lastRow: lastRow});
    });
});

app.get('/filters',(req,res)=>{
    dataService.getDistinct(req, res)

})


app.listen(port, () => {
    console.log(`Started on localhost PORT: ${port}`);
});