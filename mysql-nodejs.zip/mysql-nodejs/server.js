// import webpack from 'webpack';
// import webpackMiddleware from 'webpack-dev-middleware';
// import webpackConfig from '../webpack.config.js';
const express =require('express');
const cors =require('cors');
// import bodyParser from 'body-parser';

let OlympicWinnersService= require('./olympicWinnersService');
let olympicWinnersService = new OlympicWinnersService;

const app = express();
app.use(cors())
// app.use(webpackMiddleware(webpack(webpackConfig)));

// app.use(bodyParser.urlencoded({extended: false}));
// app.use(bodyParser.json());

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded());

// Parse JSON bodies (as sent by API clients)
app.use(express.json());

app.post('/olympicWinners', function (req, res) {
    olympicWinnersService.getData(req.body, (rows, lastRow) => {
        res.json({rows: rows, lastRow: lastRow});
    });
});

app.listen(4001, () => {
    console.log('Started on localhost:4001');
});