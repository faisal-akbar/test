export default function AddViewForm({ view, onAddFormSubmit, onAddInputChange }) {
    return (
        <form onSubmit={onAddFormSubmit} className="px-3 pt-3 mb-8">
            <div className="mb-4">
                <label
                    className="block text-gray-800 dark:text-gray-100 text-sm font-bold mb-2"
                    htmlFor="view"
                >
                    Create View
                </label>
                <input
                    className="w-full bg-slate-100 dark:bg-slate-700 shadow appearance-none border rounded py-2 px-3 text-gray-700 dark:text-gray-100 leading-tight focus:outline-none focus:shadow-outline"
                    name="view"
                    type="text"
                    placeholder="Create new view"
                    value={view}
                    onChange={onAddInputChange}
                />
            </div>
            <div className="flex items-center justify-between">
                <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    type="submit"
                    onClick={onAddFormSubmit}
                >
                    Add View
                </button>
            </div>
        </form>
    );
}
