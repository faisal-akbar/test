import { PencilAltIcon, TrashIcon, UploadIcon } from '@heroicons/react/solid';

export default function ViewItem({ view, onLoad, onEditClick, onDeleteClick }) {
    return (
        <li key={view.id} className="flex my-4 px-3 border-b border-slate-600 justify-between">
            {view.text}
            <span className="space-x-2 transition duration-500 ease-in-out rounded-full flex">
                {/* <button type="button" onClick={() => onLoad(view)}> */}
                <UploadIcon
                    onClick={() => onLoad(view)}
                    className="h-4 w-4 text-emerald-500 dark:text-emerald-400 text-2xl cursor-pointer"
                />
                <PencilAltIcon
                    onClick={() => onEditClick(view)}
                    className="h-4 w-4 text-blue-500 dark:text-blue-400 text-2xl cursor-pointer"
                />
                <TrashIcon
                    onClick={() => onDeleteClick(view.id)}
                    className="h-4 w-4 text-red-800 dark:text-red-400 text-2xl cursor-pointer"
                />
                {/* </button> */}
                {/* <button type="button" onClick={() => onEditClick(todo)}>
                    Edit
                </button>
                <button type="button" onClick={() => onDeleteClick(todo.id)}>
                    Delete
                </button> */}
            </span>
        </li>
    );
}
