export default function EditForm({
    currentView,
    setIsEditing,
    onEditInputChange,
    onEditFormSubmit,
}) {
    return (
        <form onSubmit={onEditFormSubmit} className="px-3 pt-3 mb-8">
            <label
                htmlFor="updateView"
                className="block text-gray-800 dark:text-gray-100 text-sm font-bold mb-2"
            >
                Edit View
            </label>
            <input
                className="w-full bg-slate-100 dark:bg-slate-700 shadow appearance-none border rounded py-2 px-3 text-gray-700 dark:text-gray-100 leading-tight focus:outline-none focus:shadow-outline"
                name="updateView"
                type="text"
                placeholder="Edit View"
                value={currentView.text}
                onChange={onEditInputChange}
            />
            <div className="space-x-2 my-4">
                <button
                    type="submit"
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    onClick={onEditFormSubmit}
                >
                    Update
                </button>
                <button
                    type="button"
                    className="bg-amber-600 hover:bg-amber-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                    onClick={() => setIsEditing(false)}
                >
                    Cancel
                </button>
            </div>
        </form>
    );
}
