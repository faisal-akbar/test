const sql = require('mssql/msnodesqlv8');
const moment = require('moment');

const sqlConfig = {
    database: 'sample_data',
    server: 'DESKTOP-9UFS1UJ\\SQLEXPRESS',
    driver: 'msnodesqlv8',
    options: {
        trustedConnection: true,
        // enableArithAbort: true
    },
};

class DataService {
    async getData(request, resultsCallback) {
        const connection = await sql.connect(sqlConfig);
        console.log('connected to MS-SQL');
        const SQL = this.buildSql(request);

        connection.query(SQL, (error, results) => {
            console.log('inside 1', SQL);
            console.log('inside 2', results);
            const rowCount = this.getRowCount(request, results);
            const resultsForPage = this.cutResultsToPageSize(request, results);
            // console.log("callback here", rowCount, resultsForPage)

            console.log('inside 3', rowCount);
            console.log('inside 4', resultsForPage);

            resultsCallback(resultsForPage, rowCount);
        });
    }

    buildSql(request) {
        const selectSql = this.createSelectSql(request);
        const fromSql = ' FROM dbo.superstore ';
        const whereSql = this.createWhereSql(request);
        // const limitSql = this.createLimitSql(request);

        const orderBySql = this.createOrderBySql(request);
        const groupBySql = this.createGroupBySql(request);

        const SQL = selectSql + fromSql + whereSql + groupBySql + orderBySql;
        // + limitSql;

        console.log(SQL);

        return SQL;
    }

    createSelectSql(request) {
        const { rowGroupCols } = request;
        const { valueCols } = request;
        const { groupKeys } = request;

        if (this.isDoingGrouping(rowGroupCols, groupKeys)) {
            const colsToSelect = [];

            const rowGroupCol = rowGroupCols[groupKeys.length];
            colsToSelect.push(rowGroupCol.field);

            valueCols.forEach((valueCol) => {
                colsToSelect.push(`${valueCol.aggFunc}(${valueCol.field}) as ${valueCol.field}`);
            });

            return ` select ${colsToSelect.join(', ')}`;
        }

        return ' select *';
    }

    createFilterSql(key, item) {
        switch (item.filterType) {
            case 'text':
                return this.createTextFilterSql(key, item);
            case 'number':
                return this.createNumberFilterSql(key, item);
            case 'set':
                return this.createSetFilterSql(key, item);
            case 'date':
                return this.createDateFilterSql(key, item);
            default:
                console.log(`unkonwn filter type: ${item.filterType}`);
        }
    }

    createNumberFilterSql(key, item) {
        switch (item.type) {
            case 'equals':
                return `${key} = ${item.filter}`;
            case 'notEqual':
                return `${key} != ${item.filter}`;
            case 'greaterThan':
                return `${key} > ${item.filter}`;
            case 'greaterThanOrEqual':
                return `${key} >= ${item.filter}`;
            case 'lessThan':
                return `${key} < ${item.filter}`;
            case 'lessThanOrEqual':
                return `${key} <= ${item.filter}`;
            case 'inRange':
                return `(${key} >= ${item.filter} and ${key} <= ${item.filterTo})`;
            default:
                console.log(`unknown number filter type: ${item.type}`);
                return 'true';
        }
    }

    createDateFilterSql(key, item) {
        switch (item.type) {
            case 'equals':
                return `${key} = ` + `'${moment(item.dateFrom).format('YYYY-MM-DD')}'`;
            case 'notEqual':
                return `${key} != ` + `'${moment(item.dateFrom).format('YYYY-MM-DD')}'`;
            case 'greaterThan':
                return `${key} > ` + `'${moment(item.dateFrom).format('YYYY-MM-DD')}'`;
            case 'lessThan':
                return `${key} < ` + `'${moment(item.dateFrom).format('YYYY-MM-DD')}'`;
            case 'inRange':
                return (
                    `(${key} >= ` +
                    `'${moment(item.dateFrom).format('YYYY-MM-DD')}'` +
                    ` and ${key} <= ` +
                    `'${moment(item.dateTo).format('YYYY-MM-DD')}'` +
                    `)`
                );
            default:
                console.log(`unknown number date type: ${item.type}`);
                return 'true';
        }
    }

    createTextFilterSql(key, item) {
        switch (item.type) {
            case 'equals':
                return `${key} = '${item.filter}'`;
            case 'notEqual':
                return `${key} != '${item.filter}'`;
            case 'contains':
                return `${key} like '%${item.filter}%'`;
            case 'notContains':
                return `${key} not like '%${item.filter}%'`;
            case 'startsWith':
                return `${key} like '${item.filter}%'`;
            case 'endsWith':
                return `${key} like '%${item.filter}'`;
            default:
                console.log(`unknown text filter type: ${item.type}`);
                return 'true';
        }
    }

    createSetFilterSql(key, item) {
        // console.log("in set", `"${key} IN ('${item.values.join("', '")}')"`);
        return `${key} IN ('${item.values.join("', '")}')`;
    }

    createWhereSql(request) {
        const { rowGroupCols } = request;
        const { groupKeys } = request;
        const { filterModel } = request;

        const that = this;
        const whereParts = [];

        if (groupKeys.length > 0) {
            groupKeys.forEach((key, index) => {
                const colName = rowGroupCols[index].field;
                whereParts.push(`${colName} = '${key}'`);
            });
        }

        if (filterModel) {
            const keySet = Object.keys(filterModel);

            keySet.forEach((key) => {
                const item = filterModel[key];
                // console.log("keySet", key, item)
                whereParts.push(that.createFilterSql(key, item));
                // console.log("abc",whereParts.push(that.createFilterSql(key, item)))
            });
        }

        if (whereParts.length > 0) {
            return ` where ${whereParts.join(' and ')}`;
        }
        return '';
    }

    createGroupBySql(request) {
        const { rowGroupCols } = request;
        const { groupKeys } = request;

        if (this.isDoingGrouping(rowGroupCols, groupKeys)) {
            const colsToGroupBy = [];

            const rowGroupCol = rowGroupCols[groupKeys.length];
            colsToGroupBy.push(rowGroupCol.field);

            return ` group by ${colsToGroupBy.join(', ')}`;
        }
        // select all columns
        return '';
    }

    // createOrderBySql(request) {
    //     const rowGroupCols = request.rowGroupCols;
    //     const groupKeys = request.groupKeys;
    //     const sortModel = request.sortModel;

    //     const grouping = this.isDoingGrouping(rowGroupCols, groupKeys);

    //     const sortParts = [];
    //     if (sortModel) {

    //         const groupColIds =
    //             rowGroupCols.map(groupCol => groupCol.id)
    //                 .slice(0, groupKeys.length + 1);

    //         sortModel.forEach(function (item) {
    //             if (grouping && groupColIds.indexOf(item.colId) < 0) {
    //                 // ignore
    //             } else {
    //                 sortParts.push(item.colId + ' ' + item.sort);
    //             }
    //         });
    //     }

    //     if (sortParts.length > 0) {
    //         return ' order by ' + sortParts.join(', ');
    //     } else {
    //         return '';
    //     }
    // }

    createOrderBySql(request) {
        const { sortModel } = request;

        if (sortModel.length === 0) return '';

        const sorts = sortModel.map((s) => `${s.colId} ${s.sort.toUpperCase()}`);

        return ` ORDER BY ${sorts.join(', ')}`;
    }

    isDoingGrouping(rowGroupCols, groupKeys) {
        // we are not doing grouping if at the lowest level. we are at the lowest level
        // if we are grouping by more columns than we have keys for (that means the user
        // has not expanded a lowest level group, OR we are not grouping at all).
        return rowGroupCols.length > groupKeys.length;
    }

    createLimitSql(request) {
        const { startRow } = request;
        const { endRow } = request;
        const pageSize = endRow - startRow;
        return ` limit ${pageSize + 1} offset ${startRow}`;
    }

    getRowCount(request, results) {
        if (
            results.recordsets[0] === null ||
            results.recordsets[0] === undefined ||
            results.recordsets[0].length === 0
        ) {
            return null;
        }
        const currentLastRow = request.startRow + results.recordsets[0].length;
        return currentLastRow <= request.endRow ? currentLastRow : -1;
    }

    cutResultsToPageSize(request, results) {
        console.log('cutResultsToPageSize', request);
        console.log('cutResultsToPageSize', results);
        const pageSize = request.endRow - request.startRow;
        if (results.recordsets[0] && results.recordsets[0].length > pageSize) {
            return results.recordsets[0].splice(0, pageSize);
        }
        return results.recordsets[0];
    }

    async getDistinct(req, res) {
        const connection = await sql.connect(sqlConfig);
        console.log('connected to MS-SQL');
        // const SQL = 'select DISTINCT SEGMENT FROM superstore order by SEGMENT ASC';

        connection.query(
            `select DISTINCT segment FROM dbo.superstore order by segment ASC; 
        select DISTINCT region FROM dbo.superstore order by region ASC;
        select DISTINCT category FROM dbo.superstore order by category ASC;
        select DISTINCT sub_category FROM dbo.superstore order by sub_category ASC;
        `,
            (err, rows) => {
                if (!err)
                    // console.log(rows.recordsets);
                    res.send(rows.recordsets);
                else console.log(err);
            }
        );
    }
}

module.exports = DataService;
