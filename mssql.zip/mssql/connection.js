const sql = require('mssql/msnodesqlv8');

const sqlConfig = {
    database: 'master',
    server: 'DESKTOP-9UFS1UJ\\SQLEXPRESS',
    driver: 'msnodesqlv8',
    options: {
        trustedConnection: true,
        // enableArithAbort: true
    },
};

const checkConnection = async () => {
    try {
        // make sure that any items are correctly URL encoded in the connection string
        await sql.connect(sqlConfig);
        console.log('Connected to MS-SQL');
        // const result = await sql.query`select * from mytable where id = ${value}`
        // console.dir(result)
    } catch (err) {
        console.log(err);
    }
};

checkConnection();
