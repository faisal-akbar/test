/* eslint-disable no-use-before-define */
// require('dotenv').config();
const express = require('express');
const cors = require('cors');
const sql = require('mssql/msnodesqlv8');
const moment = require('moment');

const app = express();
app.use(cors());

app.use(express.urlencoded({ extended: true }));

app.use(express.json());

const port = 8000;

const sqlConfig = {
    database: 'sample_data',
    server: 'DESKTOP-9UFS1UJ\\SQLEXPRESS',
    driver: 'msnodesqlv8',
    options: {
        trustedConnection: true,
        // enableArithAbort: true
    },
};

const getData = async (request, resultsCallback) => {
    const connection = await sql.connect(sqlConfig);
    console.log('connected to MS-SQL');
    const SQL = buildSql(request);

    connection.query(SQL, (error, results) => {
        console.log('inside 1', SQL);
        console.log('inside 2', results);
        const rowCount = getRowCount(request, results);
        const resultsForPage = cutResultsToPageSize(request, results);
        // console.log("callback here", rowCount, resultsForPage)

        console.log('inside 3', rowCount);
        console.log('inside 4', resultsForPage);

        resultsCallback(resultsForPage, rowCount);
    });
};

const buildSql = (request) => {
    const selectSql = createSelectSql(request);
    const fromSql = ` FROM dbo.superstore `;
    const whereSql = createWhereSql(request);
    const limitSql = createLimitSql(request);

    const orderBySql = createOrderBySql(request);
    const groupBySql = createGroupBySql(request);

    const SQL = selectSql + fromSql + whereSql + groupBySql + orderBySql;
    // + limitSql;

    console.log(SQL);

    return SQL;
};

const createSelectSql = (request) => {
    const { rowGroupCols } = request;
    const { valueCols } = request;
    const { groupKeys } = request;

    if (isDoingGrouping(rowGroupCols, groupKeys)) {
        const colsToSelect = [];

        const rowGroupCol = rowGroupCols[groupKeys.length];
        colsToSelect.push(rowGroupCol.field);

        valueCols.forEach((valueCol) => {
            colsToSelect.push(`${valueCol.aggFunc}(${valueCol.field}) as ${valueCol.field}`);
        });

        return ` select ${colsToSelect.join(', ')}`;
    }

    return ' select *';
};

const createFilterSql = (key, item) => {
    switch (item.filterType) {
        case 'text':
            return createTextFilterSql(key, item);
        case 'number':
            return createNumberFilterSql(key, item);
        case 'set':
            return createSetFilterSql(key, item);
        case 'date':
            return createDateFilterSql(key, item);
        default:
            console.log(`unkonwn filter type: ${item.filterType}`);
    }
};

const createNumberFilterSql = (key, item) => {
    switch (item.type) {
        case 'equals':
            return `${key} = ${item.filter}`;
        case 'notEqual':
            return `${key} != ${item.filter}`;
        case 'greaterThan':
            return `${key} > ${item.filter}`;
        case 'greaterThanOrEqual':
            return `${key} >= ${item.filter}`;
        case 'lessThan':
            return `${key} < ${item.filter}`;
        case 'lessThanOrEqual':
            return `${key} <= ${item.filter}`;
        case 'inRange':
            return `(${key} >= ${item.filter} and ${key} <= ${item.filterTo})`;
        default:
            console.log(`unknown number filter type: ${item.type}`);
            return 'true';
    }
};

const createDateFilterSql = (key, item) => {
    switch (item.type) {
        case 'equals':
            return `${key} = ` + `'${moment(item.dateFrom).format('YYYY-MM-DD')}'`;
        case 'notEqual':
            return `${key} != ` + `'${moment(item.dateFrom).format('YYYY-MM-DD')}'`;
        case 'greaterThan':
            return `${key} > ` + `'${moment(item.dateFrom).format('YYYY-MM-DD')}'`;
        case 'lessThan':
            return `${key} < ` + `'${moment(item.dateFrom).format('YYYY-MM-DD')}'`;
        case 'inRange':
            return (
                `(${key} >= ` +
                `'${moment(item.dateFrom).format('YYYY-MM-DD')}'` +
                ` and ${key} <= ` +
                `'${moment(item.dateTo).format('YYYY-MM-DD')}'` +
                `)`
            );
        default:
            console.log(`unknown number date type: ${item.type}`);
            return 'true';
    }
};

const createTextFilterSql = (key, item) => {
    switch (item.type) {
        case 'equals':
            return `${key} = '${item.filter}'`;
        case 'notEqual':
            return `${key} != '${item.filter}'`;
        case 'contains':
            return `${key} like '%${item.filter}%'`;
        case 'notContains':
            return `${key} not like '%${item.filter}%'`;
        case 'startsWith':
            return `${key} like '${item.filter}%'`;
        case 'endsWith':
            return `${key} like '%${item.filter}'`;
        default:
            console.log(`unknown text filter type: ${item.type}`);
            return 'true';
    }
};

const createSetFilterSql = (key, item) =>
    // console.log("in set", `"${key} IN ('${item.values.join("', '")}')"`);
    `${key} IN ('${item.values.join("', '")}')`;

const createWhereSql = (request) => {
    const { rowGroupCols } = request;
    const { groupKeys } = request;
    const { filterModel } = request;

    const whereParts = [];

    if (groupKeys.length > 0) {
        groupKeys.forEach((key, index) => {
            const colName = rowGroupCols[index].field;
            whereParts.push(`${colName} = '${key}'`);
        });
    }

    if (filterModel) {
        const keySet = Object.keys(filterModel);
        keySet.forEach((key) => {
            const item = filterModel[key];
            whereParts.push(createFilterSql(key, item));
        });
    }

    if (whereParts.length > 0) {
        return ` where ${whereParts.join(' and ')}`;
    }
    return '';
};

const createGroupBySql = (request) => {
    const { rowGroupCols } = request;
    const { groupKeys } = request;

    if (isDoingGrouping(rowGroupCols, groupKeys)) {
        const colsToGroupBy = [];

        const rowGroupCol = rowGroupCols[groupKeys.length];
        colsToGroupBy.push(rowGroupCol.field);

        return ` group by ${colsToGroupBy.join(', ')}`;
    }
    // select all columns
    return '';
};

// const createOrderBySql = (request) => {
//     const rowGroupCols = request.rowGroupCols;
//     const groupKeys = request.groupKeys;
//     const sortModel = request.sortModel;

//     const grouping = isDoingGrouping(rowGroupCols, groupKeys);

//     const sortParts = [];
//     if (sortModel) {

//         const groupColIds =
//             rowGroupCols.map(groupCol => groupCol.id)
//                 .slice(0, groupKeys.length + 1);

//         sortModel.forEach(function (item) {
//             if (grouping && groupColIds.indexOf(item.colId) < 0) {
//                 // ignore
//             } else {
//                 sortParts.push(item.colId + ' ' + item.sort);
//             }
//         });
//     }

//     if (sortParts.length > 0) {
//         return ' order by ' + sortParts.join(', ');
//     } else {
//         return '';
//     }
// }

const createOrderBySql = (request) => {
    const { sortModel } = request;

    if (sortModel.length === 0) return '';

    const sorts = sortModel.map((s) => `${s.colId} ${s.sort.toUpperCase()}`);

    return ` order by ${sorts.join(', ')}`;
};

const isDoingGrouping = (rowGroupCols, groupKeys) =>
    // we are not doing grouping if at the lowest level. we are at the lowest level
    // if we are grouping by more columns than we have keys for (that means the user
    // has not expanded a lowest level group, OR we are not grouping at all).
    rowGroupCols.length > groupKeys.length;

const createLimitSql = (request) => {
    const { startRow } = request;
    const { endRow } = request;
    const pageSize = endRow - startRow;
    // return ' limit ' + (pageSize + 1) + ' offset ' + startRow;
    return ` OFFSET ${startRow} ROWS FETCH NEXT ${pageSize + 1} ROWS ONLY `;
};

const getRowCount = (request, results) => {
    if (
        results.recordsets[0] === null ||
        results.recordsets[0] === undefined ||
        results.recordsets[0].length === 0
    ) {
        return null;
    }
    const currentLastRow = request.startRow + results.recordsets[0].length;
    return currentLastRow <= request.endRow ? currentLastRow : -1;
};

const cutResultsToPageSize = (request, results) => {
    console.log('cutResultsToPageSize', request);
    console.log('cutResultsToPageSize', results);
    const pageSize = request.endRow - request.startRow;
    if (results.recordsets[0] && results.recordsets[0].length > pageSize) {
        return results.recordsets[0].splice(0, pageSize);
    }
    return results.recordsets[0];
};

app.post('/data', (req, res) => {
    getData(req.body, (rows, lastRow) => {
        console.log('req response body', req.body);
        console.log('req response row', rows);
        console.log('req response last row', lastRow);
        res.json({ rows, lastRow });
    });
});

app.get('/filters', (req, res) => {
    const getDistinct = async (req, res) => {
        const connection = await sql.connect(sqlConfig);
        console.log('connected to MS-SQL');
        // const SQL = 'select DISTINCT SEGMENT FROM superstore order by SEGMENT ASC';

        connection.query(
            `select DISTINCT segment FROM dbo.superstore order by segment ASC; 
        select DISTINCT region FROM dbo.superstore order by region ASC;
        select DISTINCT category FROM dbo.superstore order by category ASC;
        select DISTINCT sub_category FROM dbo.superstore order by sub_category ASC;
        `,
            (err, rows) => {
                if (!err)
                    // console.log(rows.recordsets);
                    res.send(rows.recordsets);
                else console.log(err);
            }
        );
    };

    getDistinct(req, res);
});

app.listen(port, () => {
    console.log(`Started on localhost: ${port}`);
});
