import { Route, Routes } from 'react-router-dom';
import './App.css';
import APIContextProvider from './components/Context/apiContext';
import Layout from './components/Layout';
import NoMatch from './components/NoMatch';
import Dashboard from './components/Visualizations/Dashboard';
import SearchDashboard from './components/Visualizations/SearchDashboard';
import DashboardPage from './Pages/DashboardPage';

const App = () => (
    <APIContextProvider>
        <Layout>
            <Routes>
                <Route path="/" element={<Dashboard />} />

                <Route path="/search=:searchQuery" element={<SearchDashboard />} />

                <Route path="/dashboard" element={<DashboardPage />} />

                <Route path="*" element={<NoMatch />} />
            </Routes>
        </Layout>
    </APIContextProvider>
);

export default App;
