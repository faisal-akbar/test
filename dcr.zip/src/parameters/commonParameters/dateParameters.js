export const dateSelectorParams = [
    // {
    //     value: '',
    //     label: 'All',
    // },
    {
        value: 'Last 14 Days',
        label: 'Last 14 Days',
    },
    {
        value: 'Last 30 Days',
        label: 'Last 30 Days',
    },
    {
        value: 'Last N Days',
        label: 'Last N Days',
    },
    {
        value: 'Custom Dates',
        label: 'Custom Dates',
    },
];
export const startDateParams = [];
export const endDateParams = [];
