import { createContext, useContext, useEffect, useState } from 'react';
import {
    categoryOptions,
    regionOptions,
    segmentOptions,
    // eslint-disable-next-line prettier/prettier
    yearOptions
} from '../../reactSelectData/data';

const APIContext = createContext();

function APIContextProvider({ children }) {
    // Data
    const [apiData, setApiData] = useState([]);
    const [isFilter, setIsFilter] = useState(false);

    // Common Parameters
    // eslint-disable-next-line no-unused-vars
    // const [dateSelector, setDateSelector] = useState(dateSelectorParams[0]);
    const [isNDays, setIsNDays] = useState(false);
    const [isCustomDates, setIsCustomDates] = useState(false);

    // eslint-disable-next-line no-unused-vars
    const [selectedYear, setSelectedYear] = useState(yearOptions[0]);
    const [selectedRegion, setSelectedRegion] = useState(regionOptions);
    const [selectedSegment, setSelectedSegment] = useState(segmentOptions);
    const [selectedCategory, setSelectedCategory] = useState(categoryOptions);
    const [isLoading, setIsLoading] = useState(true);

    // Fetch data
    const dashBaseURL = 'https://public.tableau.com/views';
    const thumbBaseURL = 'https://public.tableau.com/thumb/views';

    useEffect(() => {
        fetch('data/chartApi.json')
            .then((res) => res.json())
            .then((data) => {
                setApiData(data);
                setIsLoading(false);
            })
            .catch((err) => console.log(err));
    }, []);

    return (
        <APIContext.Provider
            // eslint-disable-next-line react/jsx-no-constructed-context-values
            value={{
                isLoading,
                dashBaseURL,
                thumbBaseURL,
                apiData,
                setSelectedYear,
                selectedSegment,
                setSelectedSegment,
                selectedRegion,
                setSelectedRegion,
                selectedCategory,
                setSelectedCategory,
                isFilter,
                setIsFilter,
                // Params
                // dateSelector,
                // setDateSelector,
                isNDays,
                isCustomDates,
                setIsNDays,
                setIsCustomDates,
            }}
        >
            {children}
        </APIContext.Provider>
    );
}

export default APIContextProvider;

// Create a hook to use the APIContext, this is a Kent C. Dodds pattern
export function useAPI() {
    const context = useContext(APIContext);
    if (context === undefined) {
        throw new Error('Context must be used within a Provider');
    }
    return context;
}
