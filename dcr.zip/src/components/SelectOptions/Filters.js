import React from 'react';
import {
    categoryOptions,
    regionOptions,
    segmentOptions,
    // eslint-disable-next-line prettier/prettier
    yearOptions
} from '../../reactSelectData/data';
import { useAPI } from '../Context/apiContext';
import MultiSelect from './MultiSelect';
import SingleSelect from './SingleSelect';

const Filters = () => {
    const {
        setSelectedYear,
        setSelectedSegment,
        selectedSegment,
        selectedRegion,
        setSelectedRegion,
        selectedCategory,
        setSelectedCategory,
    } = useAPI();

    return (
        <div className=" absolute right-0 top-14 z-20 my-3 flex flex-col space-y-3 bg-gray-300 px-2 py-3 shadow-md transition-all dark:bg-gray-700 sm:w-[100]">
            <div className="border-b-2 border-gray-800 text-gray-900 dark:border-gray-100 dark:text-white">
                Filters
            </div>
            <div className="flex flex-col divide-y-2 divide-gray-200 dark:divide-gray-600">
                <div className="mb-2">
                    <div className="my-2 ml-1 text-gray-900 dark:text-white">Year</div>
                    <SingleSelect
                        className="sm:w-96"
                        options={yearOptions}
                        defaultValue={yearOptions[0]}
                        filterOptions={yearOptions}
                        changeFilter={setSelectedYear}
                    />
                </div>
                <div className="my-2">
                    <div className="my-2 ml-1 text-gray-900 dark:text-white">Region</div>
                    <MultiSelect
                        className="sm:w-96"
                        filterOptions={regionOptions}
                        value={selectedRegion}
                        setValue={setSelectedRegion}
                        name="Region"
                    />
                </div>
                <div className="my-2">
                    <div className="my-2 ml-1 text-gray-900 dark:text-white">Segment</div>
                    <MultiSelect
                        className="sm:w-96"
                        filterOptions={segmentOptions}
                        value={selectedSegment}
                        setValue={setSelectedSegment}
                        name="Segment"
                    />
                </div>
                <div className="my-2">
                    <div className="my-2 ml-1 text-gray-900 dark:text-white">Category</div>
                    <MultiSelect
                        className="sm:w-96"
                        filterOptions={categoryOptions}
                        value={selectedCategory}
                        setValue={setSelectedCategory}
                        name="Category"
                    />
                </div>
            </div>
        </div>
    );
};

export default Filters;
