import React from 'react';
import { dateSelectorParams } from '../../../parameters/commonParameters/dateParameters';
import { useAPI } from '../../Context/apiContext';
import SingleSelect from '../../SelectOptions/SingleSelect';

const CommonParameters = ({ onChangeDateSelector, onChangeNDays, onChangeStartDate }) => {
    const { isNDays, isCustomDates } = useAPI();
    console.log('test');

    return (
        <div className=" z-21 absolute right-0 top-14 my-3 flex flex-col space-y-3 bg-gray-300 px-2 py-3 shadow-md transition-all dark:bg-gray-700 sm:w-[100]">
            <div className="border-b-2 border-gray-800 text-gray-900 dark:border-gray-100 dark:text-white">
                Parameters
            </div>
            <div className="flex flex-col divide-y-2 divide-gray-200 dark:divide-gray-600">
                <div className="mb-2">
                    <div className="my-2 ml-1 text-gray-900 dark:text-white">Date Selector</div>
                    <SingleSelect
                        className="sm:w-96"
                        options={dateSelectorParams}
                        defaultValue={dateSelectorParams[0]}
                        filterOptions={dateSelectorParams}
                        // changeFilter={setDateSelector}
                        onChange={onChangeDateSelector}
                    />
                </div>
                {isNDays && (
                    <div className="mb-2">
                        <div className="my-2 ml-1 text-gray-900 dark:text-white">N Days</div>
                        <input className="p-2 sm:w-96" type="number" onBlur={onChangeNDays} />
                    </div>
                )}
                {isCustomDates && (
                    <>
                        <div className="mb-2">
                            <div className="my-2 ml-1 text-gray-900 dark:text-white">
                                Start Date
                            </div>
                            <input className="p-2 sm:w-96" type="date" onBlur={onChangeStartDate} />
                        </div>
                        <div className="mb-2">
                            <div className="my-2 ml-1 text-gray-900 dark:text-white">End Date</div>
                            <input className="p-2 sm:w-96" type="date" onBlur={onChangeNDays} />
                        </div>
                    </>
                )}

                {/* <div className="my-2">
                    <div className="my-2 ml-1 text-gray-900 dark:text-white">Region</div>
                    <MultiSelect
                        className="sm:w-96"
                        filterOptions={regionOptions}
                        value={selectedRegion}
                        setValue={setSelectedRegion}
                        name="Region"
                    />
                </div>
                <div className="my-2">
                    <div className="my-2 ml-1 text-gray-900 dark:text-white">Segment</div>
                    <MultiSelect
                        className="sm:w-96"
                        filterOptions={segmentOptions}
                        value={selectedSegment}
                        setValue={setSelectedSegment}
                        name="Segment"
                    />
                </div>
                <div className="my-2">
                    <div className="my-2 ml-1 text-gray-900 dark:text-white">Category</div>
                    <MultiSelect
                        className="sm:w-96"
                        filterOptions={categoryOptions}
                        value={selectedCategory}
                        setValue={setSelectedCategory}
                        name="Category"
                    />
                </div> */}
            </div>
        </div>
    );
};

export default CommonParameters;
