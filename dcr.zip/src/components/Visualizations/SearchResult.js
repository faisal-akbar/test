import Moment from 'moment';
import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { useAPI } from '../Context/apiContext';
import DashCardDetails from './DashCardDetails';

const SearchResult = () => {
    const { apiData, dashBaseURL, thumbBaseURL } = useAPI();
    // Read user input using useParams and filter:
    const { searchQuery } = useParams();
    const searchResult = apiData.filter((event) => {
        const title = event.title.toLowerCase();
        const searchQueryLower = searchQuery.toLowerCase();
        return title.includes(searchQueryLower);
    });
    // console.log(searchResult);

    return (
        <>
            <div className="my-4 flex flex-col ">
                <h3 className="mb-2 text-4xl font-bold text-gray-700 dark:text-gray-200">
                    Search Result
                </h3>
                <hr className="h-1 w-full rounded border-0 bg-gray-700 dark:bg-gray-300" />
            </div>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {searchResult.map((viz) => (
                    <DashCardDetails
                        key={viz.title}
                        title={viz.title}
                        url={`${dashBaseURL}/${viz.workbookRepoUrl}/${viz.defaultViewName.replace(
                            /[/\s//#?|'&]/g,
                            ''
                        )}`}
                        thumbnail={`${thumbBaseURL}/${
                            viz.workbookRepoUrl
                        }/${viz.defaultViewName.replace(/[/\s//#?|'&]/g, '')}`}
                        firstPublishDate={`${Moment(viz.firstPublishDate).format('MMM DD, YYYY')}`}
                        lastUpdate={`${Moment().diff(Moment(viz.lastPublishDate), 'days')}`}
                        views={viz.viewCount}
                        isFeatured={viz.isFeatured}
                    />
                ))}
            </div>
            <div className="my-5 text-center">
                {/* Click to show all tasks events */}
                <Link to="/">
                    <button
                        className="rounded-lg bg-yellow-800 px-3 py-2 font-semibold hover:bg-yellow-700 dark:text-gray-200"
                        type="button"
                    >
                        View All Dashboards
                    </button>
                </Link>
            </div>
        </>
    );
};

export default SearchResult;
