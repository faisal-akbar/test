import Moment from 'moment';
import React from 'react';
import { useAPI } from '../Context/apiContext';
import DashCardDetails from './DashCardDetails';

const DashCard = () => {
    const { apiData, dashBaseURL, thumbBaseURL } = useAPI();

    // console.log('Sort Data', sortData);
    // console.log('Sort Type', setSortType);

    return (
        <>
            {/* <div className="my-4 flex justify-start">
                <select
                    className="form-select rounded border-gray-500 focus:border-transparent focus:outline-none focus:ring-2 focus:ring-purple-600"
                    onChange={(e) => setSortType(e.target.value)}
                >
                    <option disabled>Sort by</option>
                    <option value="default">Default</option>
                    <option value="firstPublishDate">Recent Publish</option>
                    <option value="lastPublishDate">Last Modified</option>
                    <option value="viewCount">View Count</option>
                </select>
            </div> */}
            <div className="my-4 flex justify-center">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 2xl:gap-11">
                    {apiData.map((viz) => (
                        <DashCardDetails
                            key={viz.title}
                            title={viz.title}
                            url={`${dashBaseURL}/${
                                viz.workbookRepoUrl
                            }/${viz.defaultViewName.replace(/[/\s//#?|'&]/g, '')}`}
                            thumbnail={`${thumbBaseURL}/${
                                viz.workbookRepoUrl
                            }/${viz.defaultViewName.replace(/[/\s//#?|'&]/g, '')}`}
                            firstPublishDate={`${Moment(viz.firstPublishDate).format(
                                'MMM DD, YYYY'
                            )}`}
                            lastUpdate={`${Moment().diff(Moment(viz.lastPublishDate), 'days')}`}
                            views={viz.viewCount}
                        />
                    ))}
                </div>
            </div>
        </>
    );
};

export default DashCard;
