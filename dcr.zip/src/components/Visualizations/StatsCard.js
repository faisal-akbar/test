import {
    CalendarIcon,
    ChartBarIcon,
    EyeIcon,
    StarIcon,
    UserAddIcon,
    // eslint-disable-next-line prettier/prettier
    UserGroupIcon
} from '@heroicons/react/solid';
import React from 'react';
import { useAPI } from '../Context/apiContext';
import StatsCardDetails from './StatsCardDetails';

const StatsCard = () => {
    const { visibleVizzes, totalViews, numberFavorites, followersData, followingData } = useAPI();

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-8 dark:text-gray-300">
            <StatsCardDetails
                metric="Vizzes"
                amount={visibleVizzes.length}
                icon={<ChartBarIcon className="stats-icons" />}
                formatBefore=""
                formatAfter=""
            />
            <StatsCardDetails
                metric="Views"
                amount={Math.round(totalViews).toLocaleString()}
                icon={<EyeIcon className="stats-icons" />}
                formatBefore=""
                formatAfter=""
            />
            <StatsCardDetails
                metric="Favorites"
                amount={numberFavorites}
                icon={<StarIcon className="stats-icons" />}
                formatBefore=""
                formatAfter=""
            />
            <StatsCardDetails
                metric="Followers"
                amount={followersData.length}
                icon={<UserGroupIcon className="stats-icons" />}
                formatBefore=""
                formatAfter=""
            />
            <StatsCardDetails
                metric="Following"
                amount={followingData.length}
                icon={<UserAddIcon className="stats-icons" />}
                formatBefore=""
                formatAfter=""
            />
            <StatsCardDetails
                metric="Years"
                amount={new Date().getFullYear() - 2012}
                icon={<CalendarIcon className="stats-icons" />}
                formatBefore=""
                formatAfter="+"
            />
        </div>
    );
};

export default StatsCard;
