import { CalendarIcon, EyeIcon } from '@heroicons/react/solid';
import React from 'react';
import { Link } from 'react-router-dom';

// eslint-disable-next-line no-unused-vars
const DashCardDetails = ({
    title,
    // eslint-disable-next-line no-unused-vars
    url,
    thumbnail,
    firstPublishDate,
    lastUpdate,
    views,
}) => (
    // console.log(title);
    // console.log(url);
    <Link
        to="/dashboard"
        state={{ title, vizURL: url }}
        className="relative h-full max-w-md overflow-hidden rounded-lg shadow-md transition hover:cursor-pointer dark:bg-gray-800 dark:text-gray-200 sm:hover:scale-105"
    >
        {/* {isFeatured && (
                <div className="absolute top-3 left-3 rounded-full bg-yellow-600 px-3 py-1 text-sm text-gray-100 opacity-95">
                    Featured
                </div>
            )} */}
        <img className="w-full" src={thumbnail} alt={title} />
        <div className="h-36 px-6 py-4">
            <div className="mb-2 text-xl font-bold hover:underline">{title}</div>
            <p className="text-base text-gray-700 dark:text-gray-400 ">
                Last updated {lastUpdate} days ago.
                {/* {url} */}
            </p>
        </div>
        <div className="flex justify-between px-3 pt-4 pb-2">
            <div className="mr-2 mb-2 inline-block rounded-full bg-gray-100 px-3 py-1 text-sm dark:bg-gray-700 dark:text-gray-200">
                <CalendarIcon className="mr-2 inline h-5 w-5" />
                {firstPublishDate}
            </div>
            <div className="mr-2 mb-2 inline-block rounded-full bg-gray-100 px-3 py-1 text-sm dark:bg-gray-700 dark:text-gray-200">
                <EyeIcon className="mr-2 inline h-5 w-5" />
                {views}
            </div>
        </div>
    </Link>
);
export default DashCardDetails;
