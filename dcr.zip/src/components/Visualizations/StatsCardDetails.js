import React from 'react';

const StatsCardDetails = ({ metric, amount, icon, formatBefore, formatAfter }) => (
    <div className="chart-card flex justify-center items-center">
        <div className="mr-3">{icon}</div>
        <div className="flex flex-col justify-center items-center hover:cursor-default">
            <div className="text-2xl mb-2 ">{metric}</div>
            <h2 className="font-bold text-3xl mb-2">
                {formatBefore}
                {amount}
                {formatAfter}
            </h2>
        </div>
    </div>
);

export default StatsCardDetails;
