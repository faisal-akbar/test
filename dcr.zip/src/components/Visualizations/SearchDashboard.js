import React from 'react';
import { useAPI } from '../Context/apiContext';
import PreLoader from '../PreLoader';
import SearchResult from './SearchResult';

const SearchDashboard = () => {
    const { isLoading } = useAPI();

    return (
        <div>
            {!isLoading ? (
                <>
                    {/* <StatsCard /> */}
                    <SearchResult />
                </>
            ) : (
                <PreLoader />
            )}
        </div>
    );
};
export default SearchDashboard;
