import React from 'react';
import { useAPI } from '../Context/apiContext';
import PreLoader from '../PreLoader';
import DashCard from './DashCard';

const Dashboard = () => {
    const { isLoading } = useAPI();

    return (
        <div>
            {!isLoading ? (
                <>
                    {/* <StatsCard /> */}
                    <DashCard />
                </>
            ) : (
                <PreLoader />
            )}
        </div>
    );
};
export default Dashboard;
