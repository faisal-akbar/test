import { FilterIcon, XIcon } from '@heroicons/react/solid';
import React from 'react';
import { useAPI } from './Context/apiContext';

const FilterToggle = () => {
    const { isFilter, setIsFilter } = useAPI();
    return (
        <div className="rounded-full p-2 transition duration-500 ease-in-out">
            {!isFilter ? (
                <FilterIcon
                    onClick={() => setIsFilter(true)}
                    className="h-5 w-5 cursor-pointer text-2xl text-gray-500 dark:text-gray-400"
                />
            ) : (
                <XIcon
                    onClick={() => setIsFilter(false)}
                    className="h-5 w-5 cursor-pointer text-2xl text-gray-500 dark:text-gray-400"
                />
            )}
        </div>
    );
};
export default FilterToggle;
