import React from 'react';

const Footer = () => (
    <footer className="my-3 py-2">
        {/* <!-- Copyright --> */}
        <div className="py-2 text-center dark:text-gray-200">
            &copy;{' '}
            {new Date().getFullYear() === 2021 ? 2021 : `${2021} - ${new Date().getFullYear()}`}{' '}
            Copyright:{' '}
            <a
                className="font-semibold text-blue-400 dark:hover:text-blue-500"
                href="/"
                target="_blank"
                rel="noreferrer"
            >
                Bank of America
            </a>
        </div>
    </footer>
);

export default Footer;
