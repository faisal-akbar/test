import React from 'react';
import Banner from './Banner';
import Header from './Header';

const Layout = ({ children }) => (
    <>
        <Header />
        <div className="mx-auto w-full px-4 sm:px-10 md:px-5">{children}</div>
        <Banner />
        {/* <Footer />. */}
    </>
);

export default Layout;
