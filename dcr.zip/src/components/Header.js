import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import FilterToggle from './FilterToggle';
import Toggle from './Theme/ThemeToggle';

const Header = () => {
    const location = useLocation();
    // console.log(location.pathname);
    return (
        // <nav className="sticky top-0 z-30 flex justify-center items-center w-full px-4 py-4 my-0 mb-8 backdrop-filter backdrop-blur-lg bg-opacity-10 firefox:bg-opacity-90 border-b border-primary">
        <nav className="firefox:bg-opacity-90 sticky top-0 z-30 flex w-full items-center justify-between bg-opacity-10 p-4 shadow-md backdrop-blur-lg backdrop-filter">
            <div className="mb-3 ml-0 font-bold text-gray-900 dark:text-gray-100 sm:text-2xl md:mb-0 md:ml-4">
                <Link
                    to="/"
                    className="ml-2 font-bold text-gray-900 hover:text-yellow-700 dark:text-gray-100 dark:hover:text-blue-400 sm:text-2xl md:ml-4"
                >
                    <span>Workbench Analytics</span>
                </Link>
            </div>
            <div className="flex">
                {location.pathname === '/dashboard' && <FilterToggle />}
                <Toggle />
            </div>
        </nav>
        // </nav>
    );
};

export default Header;
