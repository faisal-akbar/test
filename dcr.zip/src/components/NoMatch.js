import React from 'react';

const NoMatch = () => (
    <div className="flex justify-center mt-5 text-3xl dark:text-gray-200">
        <h3>Page not found!</h3>
    </div>
);

export default NoMatch;
