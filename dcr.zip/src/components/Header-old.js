// import { SearchIcon } from '@heroicons/react/solid';
// import React, { useState } from 'react';
// import { Link } from 'react-router-dom';
// import Toggle from './Theme/ThemeToggle';

// const Header = () => {
//     const [searchQuery, setSearchQuery] = useState(null);
//     const getQuery = (e) => setSearchQuery(e.target.value);
//     // const location = useLocation();
//     // console.log(location.pathname);

//     return (
//         // <nav className="sticky top-0 z-30 flex justify-center items-center w-full px-4 py-4 my-0 mb-8 backdrop-filter backdrop-blur-lg bg-opacity-10 firefox:bg-opacity-90 border-b border-primary">
//         <nav className="firefox:bg-opacity-90 sticky top-0 z-30 flex w-full flex-col items-center justify-between bg-opacity-10 p-4 shadow-md backdrop-blur-lg backdrop-filter sm:flex-row">
//             <div className="mb-2 flex w-full items-center justify-between sm:mb-0">
//                 <a
//                     className="ml-2 font-bold text-gray-900 hover:text-yellow-700 dark:text-gray-100 dark:hover:text-blue-400 sm:text-2xl md:ml-4"
//                     href="/"
//                     target="_blank"
//                     rel="noreferrer"
//                 >
//                     {/* <img src={profilePic} alt="Profile" /> */}
//                     Workbench Analytics
//                 </a>

//                 <div className="inline sm:hidden">
//                     <Toggle />
//                 </div>
//             </div>

//             <div className="mr-0 flex w-full items-center justify-between sm:mr-3 sm:w-auto">
//                 <div className="relative w-full sm:w-auto">
//                     <SearchIcon className="absolute top-3 left-3 z-40 h-5 w-5 text-gray-800 " />

//                     <input
//                         type="text"
//                         onChange={getQuery}
//                         placeholder="Type here"
//                         className="z-10 h-10 w-full rounded-lg border border-transparent bg-gray-200 pl-10 pr-20 focus:border-transparent focus:outline-none focus:ring-2 focus:ring-purple-600 sm:w-72"
//                     />
//                     <Link to={`/search=${searchQuery}`} className="absolute top-1 right-1">
//                         <button
//                             type="button"
//                             onClick={() => window.scrollBy(0, 250)}
//                             className="h-8 w-20 rounded-lg bg-green-700 text-white
//                             hover:bg-green-600"
//                         >
//                             Search
//                         </button>
//                     </Link>
//                 </div>
//                 <div className="ml-2 hidden sm:inline">
//                     <Toggle />
//                 </div>
//             </div>
//         </nav>
//         // </nav>
//     );
// };

// export default Header;
