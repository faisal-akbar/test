import { ArrowLeftIcon } from '@heroicons/react/solid';
import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAPI } from '../components/Context/apiContext';
// eslint-disable-next-line import/no-cycle
import CommonParameters from '../components/Parameters/CommonParameters/CommonParameters';
import Filters from '../components/SelectOptions/Filters';

const { tableau } = window;

const DashboardPage = () => {
    document.title = 'Dashboard';
    const { isFilter } = useAPI();
    const location = useLocation();
    const { vizURL, title } = location.state;
    console.log(title);
    // eslint-disable-next-line no-unused-vars
    const [viz, setViz] = useState(null);

    const initViz = () => {
        const containerDiv = document.getElementById('container');
        const options = {
            hideTabs: true,
            hideToolbar: true,
            onFirstInteractive() {
                console.log('This viz is interactive.');
            },
        };
        setViz(new tableau.Viz(containerDiv, vizURL, options));
    };

    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(initViz, []);

    // Load Parameters
    const { setIsNDays, setIsCustomDates } = useAPI();
    const onChangeDateSelector = (selected) => {
        // console.log('onChangeDateSelector', dateSelector.value);
        console.log('onChangeDateSelector', selected.value);
        const workbook = viz.getWorkbook();
        workbook.changeParameterValueAsync('Date Selector', selected.value);
        if (selected.value === 'Custom Dates') {
            setIsCustomDates(true);
            setIsNDays(false);
        } else if (selected.value === 'Last N Days') {
            setIsCustomDates(false);
            setIsNDays(true);
        } else {
            // workbook.changeParameterValueAsync('Date Selector', selected.value);
        }
    };

    const onChangeNDays = (e) => {
        console.log('onChangeDateSelector', e.target.value);
        const workbook = viz.getWorkbook();
        workbook.changeParameterValueAsync('N Days', e.target.value);
    };
    const onChangeStartDate = (e) => {
        console.log('onChangeDateSelector', e.target.value);

        const startDate = e.target.value;
        const startYear = startDate.getUTCFullYear();
        const startMonth = startDate.getUTCMonth();
        const startDay = startDate.getUTCDate();
        const workbook = viz.getWorkbook();
        workbook.changeParameterValueAsync(
            'N Days',
            new Date(Date.UTC(startYear, startMonth, startDay))
        );
    };
    return (
        <>
            {isFilter && <Filters />}
            <CommonParameters
                onChangeDateSelector={onChangeDateSelector}
                onChangeNDays={onChangeNDays}
                onChangeStartDate={onChangeStartDate}
            />
            <div className="mt-4 flex flex-col items-center">
                {/* <button
                    type="button"
                    onClick={onChangeDateSelector}
                    className="rounded bg-blue-500 py-2 px-4 font-bold text-white hover:bg-blue-700"
                >
                    Change
                </button> */}
                {/* <button
                    type="button"
                    onClick={onChangeNDays}
                    className="rounded bg-blue-500 py-2 px-4 font-bold text-white hover:bg-blue-700"
                >
                    day Change
                </button> */}
                <Link
                    to="/"
                    className="my-3 flex items-center justify-center text-gray-700 dark:text-gray-200"
                >
                    <ArrowLeftIcon className="h-3 w-5" />
                    <span>Back</span>
                </Link>
                <div id="container" />
                <div className="my-4">
                    <h4 className="text-4xl font-semibold dark:text-gray-200">{title}</h4>
                </div>
            </div>
        </>
    );
};

export default DashboardPage;
